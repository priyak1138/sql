/*
 * Copyright 2005 by Oracle USA
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 */
package javax.ide.menu.spi;

/**
 * Represents a popup menu defined in the extension manifest.
 */
public final class PopupMenu extends SectionContainer
{
  public PopupMenu( String id )
  {
    super( id );
  }
}
