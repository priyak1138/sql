/*
 * @(#)WhileStatementT.java
 */

package javax.ide.model.java.source.tree;

/**
 * A while statement. JLS3 14.12. <p/>
 *
 * @author Andy Yu
 * */
public interface WhileStatementT
  extends ConditionalStatementT
{
}
