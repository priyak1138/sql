/*
 * @(#)FormalParameterT.java
 */

package javax.ide.model.java.source.tree;

/**
 * A formal parameter, also known as just "parameter". <p/>
 *
 * @author Andy Yu
 * */
public interface FormalParameterT
  extends VariableT
{
  // ----------------------------------------------------------------------
  
  public static final FormalParameterT[] EMPTY_ARRAY =
    new FormalParameterT[ 0 ];
}
