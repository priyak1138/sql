/*
 * @(#)ReturnStatementT.java
 */

package javax.ide.model.java.source.tree;

/**
 * A return statement. JLS3 14.17.
 *
 * @author Andy Yu
 * */
public interface ReturnStatementT
  extends SimpleStatementT
{
}
