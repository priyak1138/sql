/*
 * @(#)AnnotationExpressionT.java
 */

package javax.ide.model.java.source.tree;

/**
 * An expression wrapping an annotation. These only appear as
 * arguments to annotations. <p/>
 *
 * @author Andy Yu
 * */
public interface AnnotationExpressionT
  extends ExpressionT
{
  // ----------------------------------------------------------------------

  /**
   * @return Always non-null.
   */
  public AnnotationT getAnnotation();
}
